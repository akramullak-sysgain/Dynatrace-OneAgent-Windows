#
# Cookbook Name:: dynatrace
# Attributes:: default
#
# The Dynatrace download_link.
#default['download_link'] = 'https://{tenant_id}.live.dynatrace.com/installer/oneagent/unix/latest/{token_id}'

#default['download_link'] = 'https://qin91806.live.dynatrace.com/installer/oneagent/windows/exe/latest/zoZHJa2zPCy3RWow'

#default['download_link'] = 'https://qin91806.live.dynatrace.com/installer/oneagent/windows/msi/latest/zoZHJa2zPCy3RWow'